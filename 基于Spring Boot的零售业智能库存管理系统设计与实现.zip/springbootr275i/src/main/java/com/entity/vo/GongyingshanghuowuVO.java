package com.entity.vo;

import com.entity.GongyingshanghuowuEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 供应商货物
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2023-03-08 08:50:08
 */
public class GongyingshanghuowuVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 商品分类
	 */
	
	private String shangpinfenlei;
		
	/**
	 * 图片
	 */
	
	private String tupian;
		
	/**
	 * 规格
	 */
	
	private String guige;
		
	/**
	 * 单价
	 */
	
	private Integer danjia;
		
	/**
	 * 供应账号
	 */
	
	private String gongyingzhanghao;
		
	/**
	 * 供应商
	 */
	
	private String gongyingshang;
		
	/**
	 * 供应商手机
	 */
	
	private String gongyingshangshouji;
				
	
	/**
	 * 设置：商品分类
	 */
	 
	public void setShangpinfenlei(String shangpinfenlei) {
		this.shangpinfenlei = shangpinfenlei;
	}
	
	/**
	 * 获取：商品分类
	 */
	public String getShangpinfenlei() {
		return shangpinfenlei;
	}
				
	
	/**
	 * 设置：图片
	 */
	 
	public void setTupian(String tupian) {
		this.tupian = tupian;
	}
	
	/**
	 * 获取：图片
	 */
	public String getTupian() {
		return tupian;
	}
				
	
	/**
	 * 设置：规格
	 */
	 
	public void setGuige(String guige) {
		this.guige = guige;
	}
	
	/**
	 * 获取：规格
	 */
	public String getGuige() {
		return guige;
	}
				
	
	/**
	 * 设置：单价
	 */
	 
	public void setDanjia(Integer danjia) {
		this.danjia = danjia;
	}
	
	/**
	 * 获取：单价
	 */
	public Integer getDanjia() {
		return danjia;
	}
				
	
	/**
	 * 设置：供应账号
	 */
	 
	public void setGongyingzhanghao(String gongyingzhanghao) {
		this.gongyingzhanghao = gongyingzhanghao;
	}
	
	/**
	 * 获取：供应账号
	 */
	public String getGongyingzhanghao() {
		return gongyingzhanghao;
	}
				
	
	/**
	 * 设置：供应商
	 */
	 
	public void setGongyingshang(String gongyingshang) {
		this.gongyingshang = gongyingshang;
	}
	
	/**
	 * 获取：供应商
	 */
	public String getGongyingshang() {
		return gongyingshang;
	}
				
	
	/**
	 * 设置：供应商手机
	 */
	 
	public void setGongyingshangshouji(String gongyingshangshouji) {
		this.gongyingshangshouji = gongyingshangshouji;
	}
	
	/**
	 * 获取：供应商手机
	 */
	public String getGongyingshangshouji() {
		return gongyingshangshouji;
	}
			
}
