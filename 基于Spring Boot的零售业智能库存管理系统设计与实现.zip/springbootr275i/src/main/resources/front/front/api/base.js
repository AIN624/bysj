﻿const base = {
    url : "http://localhost:8080/springbootr275i/"
}
export default base
